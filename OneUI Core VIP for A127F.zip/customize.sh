ui_print "********************
OneUI Core VIP module

Device: Samsung Galaxy A12s (SM-A127F)

Date of the module: 26th July 2025 (07/26/2025)

Author: A French Dude

Thanks for using, enjoy!
********************"
ui_print "*************************************************
IF YOU ARE NOT ON THE SAME DEVICE AS THE MODULE IS FOR, PLEASE STOP THE INSTALLATION.
INSTALLING THIS MODULE WITH A NON-COMPATIBLE DEVICE WILL CAUSE SEVERE BOOTLOOP AND CAN BREAK YOUR SYSTEM
THE INSTALLATION WILL RESUME IN 30 SECONDS
*************************************************"
sleep 30
ui_print "-Resuming installation"
ui_print "Join t.me/AFDTechStuff for more updates!"